using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;

[Serializable]
public class Vector2Wrapper
{
    public Vector2[] spawnPoints;
}